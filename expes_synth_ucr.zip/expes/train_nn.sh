#!/bin/bash

python train_nn.py $1 $2 $3 $4
