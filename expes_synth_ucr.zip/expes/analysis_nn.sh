#!/bin/bash

python analysis_nn.py $1 $2 $3 $4 $5
